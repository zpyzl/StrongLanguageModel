/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:CollinsTest.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.utils;

/**
 * Created by zpy on 2018/8/4.
 */
public class CollinsTest {
/*
    @Test
    public void testGetAllExplains(){

       // List<CommonDictSense> allExplains = CollinsDictUtil.getAllExplains("result");
*//*
        int index = 0;
        CommonDictSense explainItem = allExplains.get(index);
        Assert.assertEquals(1, explainItem.getNumber());
        Assert.assertEquals(2, explainItem.getNumber());


        Assert.assertEquals(2, explainItem.getNumber());

        for( CommonDictSense explainItem : allExplains ){


        }*//*
    }*/
/*
    @Test
    public void testGetExp(){
        CommonDictSense explain =null;// CollinsDictUtil.getExplain("result",1);

        Assert.assertEquals(1, explain.getNumber());
        Assert.assertEquals(CollinsPOS.N_COUNT, explain.getCollinsPOS());
        Assert.assertEquals("A result is something that happens or exists because of something else that has happened.", explain.getEnExplain());
        Assert.assertEquals("结果", explain.getChExplain());
        Assert.assertEquals("Compensation is available for people who have developed asthma as a direct result of their work.", explain.getExamples().get(0).getEn());
        Assert.assertEquals("直接因工作原因患哮喘的人会获得赔偿。", explain.getExamples().get(0).getCh());


    }*/
}
