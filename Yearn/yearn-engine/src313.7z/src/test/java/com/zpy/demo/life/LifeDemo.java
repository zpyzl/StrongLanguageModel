/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:LifeDemo.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.demo.life;

/**
 * Created by zpy on 2019/7/19.
 */
public class LifeDemo {
/*
他不爱社交

一个人对与人交往的爱好程度，跟他的智力的平庸及思想的贫乏成正比

一个人
    对与人交往
        的爱好
            程度
对A的爱好 = 爱好A


原来我以为他是。。后来他变了
答：《意外》


问：忘不掉
答：《走不出回忆》

从。。变成
影响

 */


}
