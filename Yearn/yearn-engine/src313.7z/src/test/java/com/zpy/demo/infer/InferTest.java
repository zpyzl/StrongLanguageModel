/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:InferTest.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.demo.infer;

/**
 * Created by zpy on 2019/6/3.
 */
public class InferTest {
    /*
    失败是成功之母。他失败了。所以他会成功的
     */
}
