/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:EverydayDemo.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.demo.everyday;

/**
 * Created by zpy on 2019/7/19.
 */
public class EverydayDemo {

    /*
问：孩子一定要听父母的话吗？
答：只能听正确的话。但孩子还没有辨别是非能力的时候，先要问为什么，理解了为什么这样做，再遵从父母的话。
当孩子有辨别是非能力的时候，对父母的话，可以判断出应不应该，如果应该，那么就听；如果不应该，那么在不遵从父母的话之前，要向父母说明为什么不应该，努力让父母理解。

     */
}
