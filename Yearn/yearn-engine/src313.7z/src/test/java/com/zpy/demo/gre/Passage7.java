/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Passage7.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.demo.gre;

/**
 * Created by zhaopengyang on 2018/6/29.
 */
public class Passage7 {
/*
    @Test
    public void q1(){
        SentenceParser.parse(
                "Among many historians a belief persists that " +
                        "Cotton Mather’s biographies of some of the settlers of\n" +
                "the Massachusetts Bay Colony (published 1702) are exercises in hagiography, endowing their\n" +
                "subjects with saintly piety at the expense of historical accuracy");

    }*/

}
