/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:YearnWordServiceTest.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.service;

import javax.annotation.Resource;

/**
 * Created by zpy on 2018/9/14.
 */
public class YearnWordServiceTest {//extends TestBase {
    @Resource
    private YearnWordService yearnWordService;
    /*@Test
    public void testLookupWithTag() throws YearnException {
        List<StaticSense> sens = yearnWordService.lookup("自己", "PN");
        print(sens);
        Assert.assertTrue(!sens.isEmpty());
    }*/
}
