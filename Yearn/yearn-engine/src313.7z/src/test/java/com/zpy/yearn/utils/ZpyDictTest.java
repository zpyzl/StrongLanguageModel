/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:ZpyDictTest.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.utils;

/**
 * Created by zpy on 2018/8/5.
 */
public class ZpyDictTest {
/*
    @Test
    public void testGetWordContent() throws YearnException {
        String wordExplStr = MdDictUtil.getWordExplStr(MdDictUtil.ZPY_META_DICT_PATH, "because");
        Assert.assertTrue(wordExplStr.length()>0);
    }

    @Test
    public void testGetAllExpl() throws IOException, URISyntaxException, YearnException {
        List<CommonDictSense> explains = MdDictUtil.getAllExplains("because");

        Assert.assertTrue(explains.size()> 0);
    }*/
}
