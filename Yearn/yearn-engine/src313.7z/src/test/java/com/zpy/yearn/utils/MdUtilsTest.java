/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:MdUtilsTest.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.utils;

/**
 * Created by zpy on 2018/8/24.
 */
public class MdUtilsTest {
/*
    @Test
    public void testGetContentUnderT1() throws IOException, YearnException {
        String fileName = Constants.GRE_SOLUTION_PATH + "\\passage" + 4 + ".md";

        String 原文 = MdUtils.getContentUnderTitle1(fileName, "原文");
        Assert.assertEquals("African American drama has, until recently, been rooted in the mimetic tradition of modern\n" +
                "American naturalism. The most distinctive attribute of this tradition is the mechanistic, materialistic\n" +
                "conception of humanity. Naturalism sees each individual as inextricably bound to the environment\n" +
                "and depicts each person as someone controlled by, instead of controlling, concrete reality. As long\n" +
                "as African American drama maintained naturalism as its dominant mode, it could only express the\n" +
                "“plight of African American people”. Its heroes might declare the madness of reality, but reality\n" +
                "inevitably triumphed over them.\n" +
                "The surrealistic plays of Adrienne Kennedy mark one of the first departures from naturalism by an\n" +
                "African American dramatist. The overall goal of her work has been to depict the world of the soul\n" +
                "and the spirit, not to mirror concrete reality. Within this framework, Kennedy has been able to\n" +
                "portray African American minds and souls liberated from their connections to the external\n" +
                "environment.",原文.trim());
    }*/
}
