/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:TestImportant.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package yearn.sense

/**
  * Created by zpy on 2019/4/27.
  */
class TestImportant {
/*
必须就是重要吗？
你必须学会弹琴，否则就成为不了明星


 */
}
