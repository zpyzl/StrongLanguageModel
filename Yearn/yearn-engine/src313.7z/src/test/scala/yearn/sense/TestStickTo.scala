/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:TestStickTo.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package yearn.sense

/**坚持
  * Created by zpy on 2019/4/27.
  */
class TestStickTo {

  /*

   */

}
