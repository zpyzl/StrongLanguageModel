/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:HelloWorld.scala
 * Date:2020/2/20 下午2:09
 * Author: 赵鹏阳
 */

package yearn.scala

/**
  * Created by zpy on 2020/2/20.
  */
object HelloWorld {

  def main(args: Array[String]): Unit = {
    println("Hello, world!")
  }

}
