/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Tense.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.tense

import com.zpy.yearn.dict.basic.time.Will
import com.zpy.yearn.dict.meta.predicate.linkOrNot.Verb

/**
  * Created by zpy on 2019/5/19.
  */
trait Tense {

}
object Tense{
  def isSimplePresent(verb: Verb): Boolean = {
    !verb.isInstanceOf[SimplePast] && !verb.isInstanceOf[Will]
     //todo 所有其他时态
  }
}
