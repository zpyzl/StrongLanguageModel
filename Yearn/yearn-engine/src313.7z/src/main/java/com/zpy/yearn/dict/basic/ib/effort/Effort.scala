/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Effort.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.basic.ib.effort

import com.zpy.yearn.dict.basic.ib.action
import com.zpy.yearn.dict.basic.logic.conj.AllOf
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.meta.thing.entity.ownerType.EntityOfIb
import com.zpy.yearn.dict.pronoun.sth.Something

/**
  * 精力
  * Created by zpy on 2019/9/22.
  */
case class Effort() extends EntityOfIb {
  override def nounMeaning(pred: Pred): Option[Thing] = {
    Some(
      action.Think(owner(), Something())
        .or(
          PhysicalStrength().of(owner()))
        .or(
          Attention().of(owner())
        )
        .or(
          AllOf(Set(
            action.Think(owner(), Something()),
            PhysicalStrength().of(owner()),
            Attention().of(owner()))
          ))
    )
  }

  //override val chStr: String = "精力"
}
