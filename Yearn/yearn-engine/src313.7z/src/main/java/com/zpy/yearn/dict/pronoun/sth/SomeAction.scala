/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:SomeAction.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.pronoun.sth

import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.{Action, Ib}

/**
  * Created by zpy on 2018/12/21.
  */
case class SomeAction(override val actor: Ib = Somebody() ) extends Action with TSth {


  override def genArgInf: Set[Pred] = argInf1ArgFunc[Ib](sbj )

  override def verbMeaning(pred: Pred): Set[Pred] = Set()

  override def toString: String = {
    //如果是来自词语解释，那么替换成“词语+Action”，如GreetAction
    if( from._2.nonEmpty && from._2.size == 1 )
      super.toString.replace(this.getClass.getSimpleName,
        from._2.head.getClass.getSimpleName + "Action" )
    else super.toString
  }

  //override val chStr: String = "DoSomeAction"
}
