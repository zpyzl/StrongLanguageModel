/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:VerbFactory.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.factory

import com.zpy.yearn.dict.basic.ib.action._
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.other.{Sense, Twp}
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.prep.whom.To
import com.zpy.yearn.dict.pronoun.sth.Somebody
import com.zpy.yearn.dict.verb.action.concrete.Greet
import com.zpy.yearn.dict.verb.auxVerb.Want
import com.zpy.yearn.dict.verb.vi.Decline

/**
  * Created by zpy on 2019/1/22.
  */
class VerbFactory(override val twp: Twp) extends VerbFactoryBase(twp)  {
  override val vStr: String = wordStr

  override protected def matchVerbThingObj(thingSbj: Thing, thingObj: Thing):  Pred = wordStr match {
    case "打" =>
      if (objTree.isDefined) {
        objTree.get.lastChild.word match {
          case "招呼" =>
            Greet(thingSbj.asInstanceOf[Ib],
              toWhom.getOrElse(To(Somebody())).whom)
        }
      } else throw new RuntimeException("No obj of 打 found!")
    case "想" =>
      thingObj match {
        case predObj: Pred =>
          val actor = thingSbj.asInstanceOf[Ib]
          if( predObj.twp().get.rawSbjs.isEmpty) Want(actor, thingObj)
          else Think(actor, thingObj)
      }
    case vStr: String =>
      newInstanceVT(thingSbj, thingObj, vStr)
  }

  override protected def matchVI(sbj: Thing): PartialFunction[String, Pred] = {
    case "做" => Do(sbj.asInstanceOf[Ib])
    case "住"=> Live(sbj)
    case "下降" => Decline(sbj)
    case "开车" | "驾驶" => Drive(sbj.asInstanceOf[Ib])
  }

  override val meanings: Things = createVerbs

}

