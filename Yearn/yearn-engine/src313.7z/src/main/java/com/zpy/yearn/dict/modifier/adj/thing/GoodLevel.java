/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:GoodLevel.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.modifier.adj.thing;

/**
 * Created by zpy on 2018/11/17.
 */
public enum GoodLevel {
    best, very_good, good, so_so, bad, very_bad, worst
}
