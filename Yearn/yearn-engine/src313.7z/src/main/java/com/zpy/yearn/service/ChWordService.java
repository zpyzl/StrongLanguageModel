/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:ChWordService.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.service;

import org.springframework.stereotype.Component;

/**
 * Created by zpy on 2018/8/29.
 */
@Component
public class ChWordService {//extends YearnWordService {

    //public lookup()
    //todo 查询出循环依赖，则查对应英文单词
    //有道：查汉语词典和百科的解释，
    //百科：去掉释义中的“意思是”。比如：汉语成语，读音fēi cǐ jí bǐ，意思是不是这一个，就是那一个

    public void explain(String word){

    }
}
