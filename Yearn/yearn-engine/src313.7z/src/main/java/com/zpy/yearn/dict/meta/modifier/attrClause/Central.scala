/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Central.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.meta.modifier.attrClause

import com.zpy.yearn.dict.meta.thing.Thing

/**
  * 在定语从句中指代中心语。
  *
  * val e1 = SomeEntity1( mods = Set( Do1( Central(), o1 ), Do2(s2, Central() ) ) )
  * 在上面这个定语从句中：Central()就代表SomeEntity1。因为SomeEntity1还未创建，所以mods中必须用Central来指代。
  * 如果e2要匹配e1，先匹配类型SomeEntity1，再匹配定语。匹配定语时，将Central()替换为e2，即验证Do1(e2, o1 )、Do2(s2, e2)是否正确。
  *
  * Created by zpy on 2019/10/11.
  */
case class Central() extends Thing with TCentral {



}
