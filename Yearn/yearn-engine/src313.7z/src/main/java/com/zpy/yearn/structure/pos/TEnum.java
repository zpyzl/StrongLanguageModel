/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:TEnum.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.structure.pos;

/**
 * Created by zpy on 2018/10/13.
 */
public enum TEnum {
    AA,BB,;
}
