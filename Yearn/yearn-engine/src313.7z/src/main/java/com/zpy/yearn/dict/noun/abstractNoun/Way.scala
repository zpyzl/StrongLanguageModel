/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Way.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.noun.abstractNoun

import com.zpy.yearn.dict.meta.thing.entity.ownerType.EntityOfThing

/**
  * 方式
  * Created by zpy on 2019/3/30.
  */
case class Way( ) extends EntityOfThing {
  //override val chStr: String = "方式 手段 方法"
}
