/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:VerbFactoryBase.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.factory

import java.lang.reflect.Constructor

import com.zpy.yearn.dict.basic.logic.Be
import com.zpy.yearn.dict.meta.hasArgs.{LinkV, Pred, V2args, V3args, V4args}
import com.zpy.yearn.dict.meta.ib.{Action, Ib}
import com.zpy.yearn.dict.meta.modifier.IbAdj
import com.zpy.yearn.dict.meta.other._
import com.zpy.yearn.dict.meta.other.senseClassMap.SenseClassMap
import com.zpy.yearn.dict.meta.predicate.fromTree.VerbFT
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.VT
import com.zpy.yearn.dict.meta.predicate.linkOrNot.Verb
import com.zpy.yearn.dict.meta.thing.{SourceType, Thing}
import com.zpy.yearn.dict.pronoun.sth.Something
import com.zpy.yearn.dict.verb.action.vt.Evaluate
import com.zpy.yearn.structure.yearnTree.Tree
import org.slf4j.LoggerFactory

/**
  * Created by zpy on 2019/3/23.
  */
abstract class VerbFactoryBase(override val twp: Twp) extends SenseFT(twp) with VerbFT {
  final private val logger = LoggerFactory.getLogger(this.getClass)

  val vStr: String
  protected val objTree: Option[Tree] = followingSib1TreeOp

  protected def matchVerbThingObj(thingSbj: Thing, thingObj: Thing):  Pred

  protected def matchVI(sbj: Thing): PartialFunction[String, Pred] = {
    case _ => throw new RuntimeException(s"$wordStr not in dict!")
  }

  protected def matchLinkV(thingSbj: Thing, predicative: Predicative): PartialFunction[String, Pred] = {
    case _ => throw new RuntimeException(s"$wordStr not in dict!")
  }

  protected def newInstanceVT(thingSbj: Thing, obj: Sense, vStr: String): Pred = {
    if( classOf[LinkV].isAssignableFrom(senseClass) &&
      obj.isInstanceOf[IbAdj] && !thingSbj.isInstanceOf[Ib]){
      thingSbj match {
        case actionSbj: Action =>
          //系动词+形容词，形容词是形容IB的，但主语不是IB，且主语的主语是IB，那么用主语的主语。例如“克服困难是痛苦的”
          actionSbj.actor.which( actionSbj )
          doNewInstance(actionSbj.actor, obj)
      }
    }
    else
      doNewInstance(thingSbj, obj)
  }


  private def doNewInstance(thingSbj: Thing, obj: Sense) = {
    val constructors: Seq[Constructor[_]] = senseClass.getConstructors
    if (senseClass == classOf[Evaluate]) {
      Evaluate(thingSbj.asInstanceOf[Ib], obj.asInstanceOf[Thing]) //todo v3args,v4args 的创建方式待定。可能v3args v4args是不需要的，只需要v2args
    } else if (classOf[V3args].isAssignableFrom(senseClass) || classOf[V4args].isAssignableFrom(senseClass)) {
      constructors.head.newInstance(thingSbj, obj).asInstanceOf[Pred]
    } else
      constructors.filter(_.getParameterCount == 2).head.newInstance(thingSbj, obj).asInstanceOf[Pred]
  }

  def createVerbs: Array[Thing] = {
    logger.debug(s"createVerbs for: $vStr")

    def createVT(sbj: Thing, obj: Either[Thing, Predicative]): Pred = {
      val verbNoConj: Pred = {
        obj match {
          case Left(thingObj) =>
            matchVerbThingObj(sbj, thingObj)
          case Right(predicative) =>
            newInstanceVT(sbj, predicative,vStr)
        }
      }
      val pred: Pred =
        if (conjFs.nonEmpty) {
          conjFs.foldLeft(verbNoConj)(
            (temp: Pred, conj: Pred => Pred) => conj(temp))
        } else verbNoConj

      pred.credibility = twp.chatbotContext.credibility

      pred.twp_=( Some(twp))
      pred.from = (SourceType.CORPUS, Set())
      pred.mods_=(  pred.mods ++ adverbials)
      noneAdvbPreps.foreach(_.selfMeaning(pred))//noneAdvbPreps是mods之外的，
      if (twp.isMainStcVerb) {
        pred.explain() //是主句才解释。如果是从句里有“自己”，可能解释成主句的主语，这时如果先解释从句，“自己”会因为不知道主句的主语而无法正确解释。
      }

      if (complements.nonEmpty) {
        val predWithCompl = complements.foldLeft(pred)(
          (temp: Pred, complement) => complement(temp))
        predWithCompl.twp_=( Some(twp))
        predWithCompl.from = (SourceType.CORPUS, Set())
        predWithCompl
      } else pred
      /*
            if( conjs.nonEmpty){
              resPred = conjs.foldLeft(resPred)(
                (temp: Pred, conj ) => conj(temp))
            }*/
    }


    def objOrPredctvNoneEmpty( objOrPredctv: Either[Option[Things], Array[Predicative]]): Boolean = {
      objOrPredctv match {
        case Left( thingsOp ) => thingsOp.nonEmpty
        case Right(predtvs) => predtvs.nonEmpty
      }
    }

    if (objOrPredctvNoneEmpty(objOrPredicatives)) {
      val verbs: Array[Array[Pred]] = for (sbj <- sbjs) yield {
        objOrPredicatives match{
          case Left( thingsOp ) =>
            val objs = thingsOp.get
            for (objF <- objs) yield {
              createVT(sbj, Left( objF))
            }
          case Right( predtvs) =>
            for (predicative <- predtvs) yield {
              createVT(sbj, Right( predicative) )
            }
        }

      }
      verbs.flatten
    } else {
      for (sbj <- sbjs) yield {
        val verbClass = SenseClassMap.mapByWordStr(vStr).head //todo 多义词时确定义项
        if (classOf[Action].isAssignableFrom(verbClass) && sbjs.length == 1 && !sbjs.head.isInstanceOf[Ib]) {
          //谓语是action, 主语位置不是IB，说明是宾语前置
          createVT(twp.sentence.defaultSbjs.getOrElse(throw new RuntimeException("宾语前置，但是no defaultSbj!")).head, Left(sbj))
        } else {
          if (passiveVoice) {
            //todo low priority “被”后面带有名词，作主语
            createVT(Something(), Left(sbj))
          }
          else matchVI(sbj)(vStr)
        }

      }
    }


  }


}
