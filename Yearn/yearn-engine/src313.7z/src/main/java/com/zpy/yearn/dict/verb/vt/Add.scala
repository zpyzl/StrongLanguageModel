/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Add.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.vt

import com.zpy.yearn.dict.meta.hasArgs.{Entity, Pred}
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVT
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * 增添
  * Created by zpy on 2019/10/6.
  */
class Add(override val actor: Ib, override val obj: Thing,
          toWhat: Entity[_], //添加到。。
          ) extends ActionVT {
  override def verbMeaning(pred: Pred): Set[Pred] = {
    Set( Let( actor, Belong(obj, toWhat) ))
  }
}
