/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Get.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.vt

import com.zpy.yearn.dict.basic.belonging
import com.zpy.yearn.dict.meta.hasArgs.{Pred, V2args}
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.pronoun.sth.Something
import com.zpy.yearn.dict.verb.action.vi.Begin
import com.zpy.yearn.structure.sense.StaticSense

/**
  * Created by zpy on 2019/10/5.
  */
case class Get(override val actor: Ib, override val obj: Thing ) extends ActionVT {
  override def verbMeaning(pred: Pred): Set[Pred] = {

    //如果obj是动作，成为动作(抽象概念)的宾语
    obj match {
      case v2argsObj: V2args if v2argsObj.obj == Something() =>
        Set(v2argsObj.copy().replaceWithMeaning( Some(actor), "obj"))
      case _ =>
        Set( Begin( belonging.Have( actor, obj )))
    }
  }
}
object Get extends StaticSense {
  override val words: String = "获得 获取 取得 得到"
}
