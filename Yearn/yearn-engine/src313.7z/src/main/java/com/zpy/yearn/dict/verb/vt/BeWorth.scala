/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:BeWorth.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.vt

import com.zpy.yearn.dict.basic.normal.Should
import com.zpy.yearn.dict.meta.hasArgs.{Entity, Pred}
import com.zpy.yearn.dict.meta.ib.{Action, Ib}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.VT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.verb.action.vt
import com.zpy.yearn.dict.verb.action.vt.Pay
import com.zpy.yearn.structure.sense.StaticSense

/**
  * Created by zpy on 2019/10/11.
  */
case class BeWorth(override val sbj: Thing , override val obj: Thing ) extends VT {
  override def verbMeaning(pred: Pred): Set[Pred] = {
    val target: Action = sbj match {
      case entitySbj: Entity[_] => vt.Get( pred.twp.get.sentence.defaultSbjs.get.head.asInstanceOf[Ib]  ,entitySbj )
      case _ => sbj.asInstanceOf[Action]
    }
    val pay: Action = obj match {
      case entityObj: Entity[_] => Pay( pred.twp.get.sentence.defaultSbjs.get.head.asInstanceOf[Ib], entityObj)
      case _ => obj.asInstanceOf[Action]
    }

    //为了。。付出是应该的
    Set( pay.inOrderTo(target).copyReplaceMods(Set(Should())))
  }
}
object BeWorth extends StaticSense{
  override val words: String = "值得"
}