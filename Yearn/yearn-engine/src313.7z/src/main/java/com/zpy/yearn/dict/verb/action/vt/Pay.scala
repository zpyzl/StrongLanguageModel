/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Pay.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.vt

import com.zpy.yearn.dict.basic.ib.Good
import com.zpy.yearn.dict.basic.logic.Be
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVT
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * Created by zpy on 2019/10/11.
  */
case class Pay(override val actor: Ib, override val obj: Thing ) extends ActionVT {
  override def verbMeaning(pred: Pred): Set[Pred] = {
    Set( Lose( actor, obj.copyReplaceMods( Set(Be(obj, Good().to(actor)) ))))
  }
}
