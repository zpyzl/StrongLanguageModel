/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:UsePrepFT.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.prep.thing

import com.zpy.yearn.dict.meta.adv.prep.NoneAdvbPrep
import com.zpy.yearn.dict.meta.other.{HasFollowerFT, SenseFT, Twp}
import com.zpy.yearn.dict.meta.predicate.fromTree.WayFT
import com.zpy.yearn.structure.pos.Constituent

/**
  * Created by zpy on 2018/12/12.
  */
class UsePrepFT(override val twp: Twp) extends SenseFT(twp) with HasFollowerFT with WayFT {
  //twp.sentence.toAddPredUse = Some(follower(Constituent.ADVERBIAL))
  //prep谓语target还没解析。
  val preps: Array[NoneAdvbPrep ] =
    for (follower <- followers(Constituent.ADVERBIAL)) yield {
      UsePrep(follower)
    }
}
