/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Use.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.way

import com.zpy.yearn.dict.basic.ib.action.ActionModel
import com.zpy.yearn.dict.meta.hasArgs.{Entity, Pred}
import com.zpy.yearn.dict.meta.ib.{Action, Ib}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.threeArgs.ActionVTComplement
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.pronoun.sth.{SomeAction, Somebody, SomethingPred}
import com.zpy.yearn.dict.verb.vi.TakeEffect

/**
  * 用：
  * 是义元，不需要再转换为因果。如果转化为因果，会失去主观原因和客观原因的区分。
  * actor use obj to targetV  =inf>   注意这是inf转换
  * Cause(actor, obj, target)  actor是主观原因，obj是客观原因
  *
  *
  * Created by zpy on 2018/11/17.
  */
case class Use(override val actor: Ib = Somebody(),
               override val obj: Thing,
               override val complement: Pred = SomethingPred(),
               override val result: Pred = SomethingPred(),//todo result或许可以去掉，用时态表示

               ) extends ActionVTComplement {
  override val target: Pred = complement

  override def verbMeaning(pred: Pred): Set[Pred] = {
    val verbObj: Pred = objThing2Verb(obj)
    target match {
      case targetAction: Action => targetAction.use_+=(verbObj)
      case _ => target.causes_+=(verbObj)
    }
    Set(ActionModel(actor, obj, target, result))
  }

  def objThing2Verb(obj: Thing): Pred =
    obj match {
      case ib: Ib => SomeAction(ib)
      case entity: Entity[_] => TakeEffect(entity)
      case verb: Pred => verb
    }


  //是介词，设置谓语的相应属性,取后面的宾语作为属性内容
  //获取宾语
  //todo 可以服用在所有宾语是动词的。近义词，依赖，凭借，是被动收益不是主动驱使
  //val action: Action =
  //val use: Verb =  //造一个带动词的

  //override val target: Action
  //def target = this.target
  //override val obj: Verb = obj
  //override val chStr: String = "用 使用 采用"
}
