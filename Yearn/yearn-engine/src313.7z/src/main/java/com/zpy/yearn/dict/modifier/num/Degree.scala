/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Degree.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.modifier.num

/**
  * 程度
  * Created by zpy on 2019/5/7.
  */
abstract class Degree{//} extends Sense {
  val num: Int
}