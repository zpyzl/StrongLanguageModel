/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Basic.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.modifier.adj.thing

import com.zpy.yearn.dict.basic.amount.absolute.Many
import com.zpy.yearn.dict.basic.belonging.Part
import com.zpy.yearn.dict.meta.adv.AdjAdv
import com.zpy.yearn.dict.meta.hasArgs.{Cause, Pred}
import com.zpy.yearn.dict.meta.modifier.Adj
import com.zpy.yearn.dict.meta.thing.{Explainer, Thing}
import com.zpy.yearn.dict.prep.thing.In
import com.zpy.yearn.structure.sense.StaticSense

/**
  * 组成其他的
  *
  * Created by zpy on 2019/7/19.
  */
case class Basic(inScope: In) extends Adj {
  override def adjMeaning(pred: Pred, centralExplainer: Explainer, advs: Set[AdjAdv] ): Either[Option[Thing], Adj] = {
    val scope = inScope.obj
    Left(Some(
      Cause(Seq(centralExplainer.fm), Part().which(Many()).otherThan(centralExplainer.fm).of(scope) )) )//many other in )
  }

  //override val chStr: String = "基本"
}
object Basic extends StaticSense{
  override val words: String = "基本"
}