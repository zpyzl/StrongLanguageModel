/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Indicate.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.basic.logic.pred

import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.VT
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * 说明
  * Created by zpy on 2019/9/26.
  */
case class Indicate(override val sbj: Thing, override val obj: Thing
  ,) extends VT {
  override def verbMeaning(pred: Pred): Set[Pred] = Set()

  //override val chStr: String = "说明"
}
