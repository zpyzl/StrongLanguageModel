/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Difficulty.scala
 * Date:2020/3/8 下午12:36
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.noun.abstractNoun

import com.zpy.yearn.dict.basic.{logic, time}
import com.zpy.yearn.dict.basic.logic.Be
import com.zpy.yearn.dict.basic.time.Happen
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.modifier.attrClause.Central
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.meta.thing.entity.ownerType.EntityOfThing
import com.zpy.yearn.dict.modifier.adj.thing.Hard
import com.zpy.yearn.dict.noun.abstractNoun.human.Target
import com.zpy.yearn.dict.pronoun.sth.Something
import com.zpy.yearn.dict.verb.auxVerb.Want
import com.zpy.yearn.dict.verb.{auxVerb, vt}
import com.zpy.yearn.dict.verb.vt.Let

/**
  * Created by zpy on 2020/3/8.
  */
case class Difficulty() extends EntityOfThing{
  override def nounMeaning(pred: Pred): Option[Thing] = {
    Some(
      Something().which(
        Let(Central(),
          logic.Be(
            time.Happen(Target().of(ib(pred))),
            Hard())
        )
      )
    )
  }
}
