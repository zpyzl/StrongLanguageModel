/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Lose.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.vt

import com.zpy.yearn.dict.basic.belonging
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.verb.action.vi.Begin

/**
  * Created by zpy on 2019/9/21.
  */
case class Lose(override val actor: Ib, override val obj: Thing ) extends ActionVT {

  override def selfMeaning(pred: Pred): Boolean = {
    this.nature_+=( Begin( belonging.Have(actor, obj).not() ),pred)
    true
  }

  //override val chStr: String = "丢失 丢 失去"
}
