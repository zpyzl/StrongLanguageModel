/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:YoudaoDictUtil.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.utils;

/**
 * Created by zpy on 2018/7/19.
 */
public class YoudaoDictUtil {

    //public static get
}
