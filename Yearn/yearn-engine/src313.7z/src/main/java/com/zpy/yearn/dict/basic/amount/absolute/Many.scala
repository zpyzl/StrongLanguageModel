/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Many.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.basic.amount.absolute

import com.zpy.yearn.dict.meta.adv.AdjAdv
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.modifier.{Adj, TQuantifier}
import com.zpy.yearn.dict.meta.thing.{Explainer, Thing}

/**
  * Created by zpy on 2019/7/21.
  */
case class Many( ) extends Adj with TQuantifier{
  /**
    * 形容词的解释只需要实现此方法
    *
    * @param centralExplainer.fm
    * @return
    */
  override def adjMeaning(pred: Pred, centralExplainer: Explainer, advs: Set[AdjAdv] ): Either[Option[Thing], Adj] = {
    //centralExplainer.fm默认Definite就是a，把其mods中的many去掉（adj.selfMeaning做了，这里不必做），在谓语上加Many
    pred.copyAddMods(Set(Many()))
    Left(None)
  }

  //override val chStr: String = "很多 非常多"
}
