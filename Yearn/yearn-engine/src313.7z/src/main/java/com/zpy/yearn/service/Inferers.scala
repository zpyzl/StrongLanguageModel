/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Inferers.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.service

import com.zpy.yearn.dict.adv.OnlySbj
import com.zpy.yearn.dict.basic.logic.Be
import com.zpy.yearn.dict.meta.hasArgs.{Cause, Pred, V2args, V3args, V4args}
import com.zpy.yearn.dict.meta.other.{Predicative, Sense}
import com.zpy.yearn.dict.meta.pred.{PredExtractor, PredPairInfer}
import com.zpy.yearn.dict.meta.thing.{AttrsCompareMethod, SourceType, Thing}
import com.zpy.yearn.dict.noun.abstractNoun.Value
import com.zpy.yearn.dict.verb.action.vt.beAdjPrep.BeDisappointedAbout
import com.zpy.yearn.facade.context.BotContext
import org.slf4j.LoggerFactory

import scala.collection.mutable

/**
  * Created by zpy on 2019/1/16.
  */
object Inferers {

  private val logger = LoggerFactory.getLogger(this.getClass)

  val isLogicFound: mutable.Set[Be] = mutable.Set()
  val msg: mutable.Set[String] = mutable.Set()

  val predExtractors: Set[PredExtractor] = Set(Value)
  val pairInferers: mutable.Set[PredPairInfer] = mutable.Set()

  Inferers.pairInferers += BeDisappointedAbout

  def extract(): Set[Pred] = {
    predExtractors.flatMap(_.extractPreds(Knowledge.all()))
  }

  def run(chatbotContext: BotContext): Unit = {
    Knowledge.all().foreach {
      case be: Be =>
        be.predicative match {
          case thingPredicative: Thing =>
            //a be m thing(m修饰thing)，那么a be m
            thingPredicative.mods.foreach((mod: Sense) => mod match {
              case predicativeNewMod: Predicative =>
                  val beMod = Be(be.sbj, predicativeNewMod)
                  be.eqvls_+=(beMod, SourceType.BE_MOD)
                print()
              case _ =>
            })
            //todo 同时a be thing, a有thing的所有一般性质。但需要受m限制，即如果thing的一般性质和m冲突，选择m

          case _ =>
        }
      case _ =>
    }

    runEach2()

    /*chatbotContext match {
      case _: PsychoCounselContext =>
        Knowledge.received.foreach {
          case cause: Cause =>
            cause.result.realPred match {
              case mood: TMood => //对情绪的因果关系进行判断是否正确

            }
          case _ =>
        }
      case _ =>
    }*/

  }

  def runEach2(): Unit = {
    runEach2Received()
    runAllEach2()
  }

  def runEach2Received(): Unit = {
    val allReceived = Knowledge.received
    allReceived.foreach(p => {
      allReceived.foreach(q => {
        logger.debug(s"p: $p, q: $q")
        if (q != p) {
          if( Knowledge.all().size > 34)
            print()
          if (p.is( q,AttrsCompareMethod.MODS_IS_MATCH)) {
            val foundIsLogicMsg = s"Found Is logic: '$p' is '$q'"
            logger.info(foundIsLogicMsg)
            if (!p.isInstanceOf[Be] && !q.isInstanceOf[Be]) {//暂时避免太复杂的be嵌套，会导致不好理解、debug麻烦
              val is = Be(p, q)
              is.from = (SourceType.IS_LOGIC, Set(p,q) )
              isLogicFound += is
              msg += foundIsLogicMsg
              Knowledge.multiToOneInfs_+=(is, p, q)
            }
            //暂时不需要，因为selfIs里面会判断Inf。~~判断p is q，那么p的infs和inferredFrom都is q
            //p.flatSynonyms.foreach( foundIsLogic(_,q))
          }
        }
      })
    })
  }

  def runAllEach2(): Unit = {
    val all = Knowledge.all()
    all.foreach(p => {
      all.foreach(q => {
        logger.debug(s"a: $p, b: $q")
        if (q != p) {
          pairInferers.map(_.infer(p, q))

          if (p.getClass == q.getClass) {

            if (p.mods.nonEmpty && p.mods.exists(_.isInstanceOf[OnlySbj])) {
              //p contains OnlySbj adv
              p match {
                case cause1: Cause =>
                  val cause2: Cause = q.asInstanceOf[Cause]
                  /*
                    已知 only a -> b, d is b, c is not a,
                    then c -> d is false
                    */
                  if (cause1.reasons.size == 1 && cause2.reasons.size == 1 &&
                    cause2.result.is(cause1.result,AttrsCompareMethod.MODS_IS_MATCH) &&
                    cause2.reasons.head.isNot(cause1.reasons.head)) {
                    val msg = s"For the OnlySbj rule: only a -> b, d is b, c is not a, then c -> d is false: \nThe result of '$cause2'(${cause2.result}) is the result of '$cause1'(${cause1.result}), but the reason of '$cause2'(${cause2.reasons.head}) isNot the reason of '$cause1'(${cause1.reasons.head}) "
                    if (cause1.credibility == cause2.credibility) {
                      throw new RuntimeException(s"$msg, but '$cause1' and '$cause2' have the same credibility of ${cause1.credibility}. ")
                    } else if (cause1.credibility == 10) {
                      logger.debug(s"$msg, the credibility of '$cause1' == 10, so $cause2 is false")
                      Knowledge.falses += cause2
                    } else if (cause2.credibility == 10) {
                      logger.debug(s"$msg, the credibility of '$cause2' == 10, so $cause1 is false")
                      Knowledge.falses += cause1
                    } else {
                      Knowledge.questionable += cause1
                      Knowledge.questionable += cause2
                      logger.debug(s"$msg, neither Preds has a credibility of 10, so they are both questionable")
                    }

                  }
                case pv4: V4args => //todo  补全
                case pv3: V3args =>
                case pv2: V2args => {
                  val qv2: V2args = q.asInstanceOf[V2args]
                  if (qv2.obj.is(pv2.obj,AttrsCompareMethod.MODS_IS_MATCH)) {
                    logger.debug(s"Found Is logic of obj: ${qv2.obj}(obj of $qv2) is ${pv2.obj}(obj of $pv2)")
                    //todo OnlySbj rule same as in Cause
                  }
                }

                case _ =>

              }

            }


          }
        }
      })
    })


  }

}
