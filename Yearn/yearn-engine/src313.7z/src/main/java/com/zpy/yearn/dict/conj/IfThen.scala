/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:IfThen.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.conj
import com.zpy.yearn.dict.meta.hasArgs.{Pred, V2args}
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * Created by zpy on 2019/9/5.
  */
case class IfThen(cond: Pred, result: Pred ) extends V2args with Conj {
  override val sbj: Thing = cond
  override val obj: Thing = result
  override def genArgInf: Set[Pred] = argInfV2argsFunc[Pred, Pred] (cond, result)

  override def toString: String = "If " + cond + ", " + result

  override def verbMeaning(pred: Pred): Set[Pred] = Set()

  //override val chStr: String = "如果"
}
