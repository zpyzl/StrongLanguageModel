/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Do.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.basic.ib.action

import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.predicate.continuous.VC
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.oneArg.ActionVI
import com.zpy.yearn.structure.sense.StaticSense

/**
  * Created by zpy on 2019/3/30.
  */
case class Do(actor: Ib
              ) extends ActionVI with VC{
  //override val chStr: String = "做"
}
object Do extends StaticSense{
  override val words: String = "做"
}