/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Dejected.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.modifier.adj.mood

import com.zpy.yearn.dict.basic.desire.Desire
import com.zpy.yearn.dict.basic.ib.Mood
import com.zpy.yearn.dict.basic.logic
import com.zpy.yearn.dict.meta.adv.AdjAdv
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.modifier.Adj
import com.zpy.yearn.dict.meta.thing.{Explainer, Thing}
import com.zpy.yearn.dict.modifier.adj.meta.TBad
import com.zpy.yearn.dict.modifier.adj.thing.Bad
import com.zpy.yearn.dict.pronoun.sth.Something
import com.zpy.yearn.dict.verb.vt.Satisfy
import com.zpy.yearn.structure.sense.StaticSense

/**
  * Created by zpy on 2019/5/14.
  */
case class Dejected() extends TBad{
  override def adjMeaning(pred: Pred, centralExplainer: Explainer, advs: Set[AdjAdv] ): Either[Option[Thing], Adj] = {
    Left(Some(
      logic.Be(
        Mood().of(centralExplainer.fm.asInstanceOf[Ib] ),
        Mood().which(Bad()).a()
           ).because( Satisfy(Something(), Desire().of( centralExplainer.fm.asInstanceOf[Ib])).did().not() )))
  }

  //override val chStr: String = "沮丧"
}
object Dejected extends StaticSense{
  override val words: String = "沮丧"
}
