/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Result.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.basic.cause

import com.zpy.yearn.dict.meta.thing.entity.ownerType.EntityOfThing

/**
  * Created by zpy on 2019/4/4.
  */
case class Result( ) extends EntityOfThing{
  //override val chStr: String = "结果 结局"
}
