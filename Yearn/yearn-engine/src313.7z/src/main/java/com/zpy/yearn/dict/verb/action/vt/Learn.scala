/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Learn.scala
 * Date:2020/1/28 下午9:37
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.vt

import com.zpy.yearn.dict.basic.belonging
import com.zpy.yearn.dict.basic.belonging.Property
import com.zpy.yearn.dict.basic.logic.pred.possibility.Can
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.{Action, Ib}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.verb.vt.Let
import com.zpy.yearn.structure.sense.StaticSense

/**
  * Created by zpy on 2020/1/28.
  */
case class Learn(override val actor: Ib, override val obj: Thing) extends ActionVT {
  override def verbMeaning(pred: Pred): Set[Pred] = Set(
    obj match {
      case ib: Ib =>
        Let(actor,
          belonging.Have(actor, Property().s().of(ib)))
      case action: Action =>
        //学习某动作，使自己能够做该动作
        Let(actor, action.copyPred(actor, Set(Can())))

    }
  )
}

object Learn extends StaticSense{
  override val words: String = "学 学习"
}
