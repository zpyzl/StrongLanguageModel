/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Adapt.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.vt

import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.VT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.verb.action.vi.ChangeVI

/**
  * Created by zpy on 2019/10/6.
  */
case class Adapt(override val sbj: Thing, override val obj: Thing ) extends VT {
  override def verbMeaning(pred: Pred): Set[Pred] = {
    Set(ChangeVI(sbj).because(obj))
  }
}
