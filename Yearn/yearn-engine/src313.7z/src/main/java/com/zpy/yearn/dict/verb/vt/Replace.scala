/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Replace.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.vt

import com.zpy.yearn.dict.meta.hasArgs.{Cause, Pred}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.threeArgs.VTComplement
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * 要补钙，可以用什么代替喝牛奶？
  * Created by zpy on 2019/10/27.
  */
case class Replace(override val sbj: Thing, override val obj: Thing,
                   override val complement: Pred,
                    ) extends VTComplement {

  override def selfMeaning(pred: Pred): Boolean = {
    complement match {
      case predCompl: Pred =>
        nature_+=( new Cause( obj, predCompl), pred)
        nature_+=( new Cause( sbj, predCompl ), pred)
      case _ => throw new RuntimeException("Replace now only support Cause!")
    }

    true
  }
}
