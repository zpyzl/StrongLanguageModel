/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:UsePrep.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.prep.thing

import com.zpy.yearn.dict.meta.adv.prep.NoneAdvbPrep
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Action
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * Created by zpy on 2019/6/24.
  */
case class UsePrep(override val obj: Thing) extends NoneAdvbPrep {

  override def selfMeaning(pred: Pred): Boolean = {
    target(pred).use_+=(obj)
    true
  }

  def target(predicate: Pred): Action =
       predicate.asInstanceOf[Action]

  //override val chStr: String = "用 凭借"
}
