/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:AppearInFrontOf.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.vt

import com.zpy.yearn.dict.basic.ib.sense
import com.zpy.yearn.dict.basic.normal.CommonIb
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.VT
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * Created by zpy on 2019/11/11.
  */
case class AppearInFrontOf(override val sbj: Thing, override val obj: Thing) extends VT {
  override def verbMeaning(pred: Pred): Set[Pred] = {
    Set(
      sense.See(obj match {
        case ib: Ib => ib
        case _ => defaultIbSbj.getOrElse(CommonIb())
      }, sbj )
    )
  }
}
