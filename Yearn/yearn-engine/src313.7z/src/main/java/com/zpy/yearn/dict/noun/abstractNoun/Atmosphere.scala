/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Atmosphere.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.noun.abstractNoun

import com.zpy.yearn.dict.meta.thing.entity.ownerType.EntityOfThing

/**
  * 例句
  * Created by zpy on 2019/11/24.
  */
case class Atmosphere() extends EntityOfThing{
  /*override def nounMeaning(pred: Pred): Option[Thing] = {
    Some(

    )
  }*/
}
