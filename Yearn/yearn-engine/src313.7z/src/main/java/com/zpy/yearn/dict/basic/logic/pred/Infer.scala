/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Infer.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.basic.logic.pred

import com.zpy.yearn.dict.conj.Conj
import com.zpy.yearn.dict.meta.hasArgs.{Pred, V4args}
import com.zpy.yearn.dict.meta.thing.{SourceType, Thing}
import com.zpy.yearn.dict.pronoun.nothing.Nothing

/**
  * 推理，由。。推出。。
  * Created by zpy on 2019/10/6.
  */
case class Infer(conditions: Set[Pred], result: Pred,
                 ) extends V4args with Conj  {

  if( conditions.size > 3 )
    throw new RuntimeException("Infer which has > 3 conditions are not supported!")

  conditions.foreach( (cond: Pred ) => {
    cond.from = (SourceType.AS_CONDITION, Set(this))
    cond.predTakingThis = Some(this)
  })
  result.from = (SourceType.AS_RESULT, Set(this))
  result.predTakingThis = Some(this)

  val condsSeq: Seq[Pred] = conditions.toSeq

  override val sbj: Thing = condsSeq.head
  override val obj: Thing = conditions.size match {
    case 1 => result
    case _ => condsSeq(1)
  }
  override val arg3: Thing =
    if( conditions.size >= 3 ) condsSeq(2)
    else if( conditions.size == 2 ) result
    else Nothing()
  override val arg4: Thing =
    if( conditions.size >= 4 ) condsSeq(3)
    else if( conditions.size == 3 ) result else Nothing()

  def this(condition: Pred, result: Pred)={
    this( Set( condition), result)
  }


  def genArgInf: Set[Pred] = conditions.size match {
    case 1 => argInfV2argsFunc[Pred, Pred] (condsSeq.head, result)
    case 2 => argInfV3argsFunc[Pred, Pred, Pred] (condsSeq.head, condsSeq.last, result)
    case 3 => argInfV4argsFunc[Pred, Pred, Pred, Pred] (condsSeq(0), condsSeq(1), condsSeq(2), result)
  }


  override def toString: String = {
    ( predModStr + " " +nonePredModStr + " " + conditions + " infers " + result )
      .replace("WrappedArray(","")
      .replace("List(","")
      .replace(")","")
  }
}
