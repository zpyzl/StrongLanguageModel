/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Plan.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.noun.abstractNoun.human

import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.meta.thing.entity.ownerType.EntityOfIb

/**
  * Created by zpy on 2019/10/29.
  */
case class Plan() extends EntityOfIb{
  override def nounMeaning(pred: Pred): Option[Thing] = {
    Some( Target().of( owner())  )
  }
}
