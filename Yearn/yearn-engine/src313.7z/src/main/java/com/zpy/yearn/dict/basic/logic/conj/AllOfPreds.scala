/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:AllOfPreds.scala
 * Date:2020/1/3 下午12:04
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.basic.logic.conj

import com.zpy.yearn.dict.meta.hasArgs.{Pred, V4args}
import com.zpy.yearn.dict.meta.thing.{SourceType, Thing}
import com.zpy.yearn.dict.pronoun.nothing.Nothing

/**
  * Created by zpy on 2019/10/28.
  */
case class AllOfPreds(preds: Set[Pred] ) extends V4args {
  if( preds.size > 4 )
    throw new RuntimeException("MultiPred which has > 4 preds are not supported!")

  preds.foreach(p => {
    p.from = (SourceType.AS_ITEM, Set(this))
    p.predTakingThis = Some(this)
  } )


  val predsSeq: Seq[Pred] = preds.toSeq
  override val sbj: Thing = predsSeq.head
  override val obj: Thing = predsSeq(1)

  override val arg3: Thing =
    if( preds.size >= 3 ) predsSeq(2)
    else Nothing()

  override val arg4: Thing =
    if( preds.size >= 4 ) predsSeq(3)
    else Nothing()




  def genArgInf: Set[Pred] = preds.size match {
    case 2 => argInfV2argsFunc[Thing, Thing] (sbj, obj)
    case 3 => argInfV3argsFunc[Thing, Thing, Thing] (sbj, obj, arg3)
    case 4 => argInfV4argsFunc[Thing, Thing, Thing, Thing] (sbj, obj, arg3, arg4)
  }

}
