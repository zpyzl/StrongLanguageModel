/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:AnyEntity.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.pronoun

import com.zpy.yearn.dict.meta.thing.entity.ownerType.EntityOfThing

/**
  * Created by zpy on 2019/7/20.
  */
case class AnyEntity( ) extends EntityOfThing{
  //override val chStr: String = "任何"
}
