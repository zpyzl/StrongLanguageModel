/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Let.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.vt

import com.zpy.yearn.dict.meta.hasArgs.{Cause, Pred}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.VT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.structure.sense.StaticSense

/**
  * 使，让
  * 1. let sb do sth
  *
  * Created by zpy on 2019/8/16.
  */
case class Let(override val sbj: Thing, override val obj: Thing ) extends VT {
  override def verbMeaning(pred: Pred): Set[Pred] =
    Set( new Cause( sbj, obj ))
}
object Let extends StaticSense{
  override val words: String = "使 让"
}