/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:QuestionGenerator.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.service.psychoCounsel

/**
  * Created by zpy on 2019/5/10.
  */
object QuestionGenerator {
/*
  def gen(): TQuestion = {
    Knowledge.all()
  }

  def detectPessimism(pred: Pred): Option[Pred] = {
    pred match {
      case predInNot: Not if( predInNot. )
    }

  }
  def containSense(pred: Pred, senseClazz: Class[_ <: Sense]): Boolean = {
    if( senseClazz.isAssignableFrom(pred.getClass)){
      true
    }else {

    }
  }*/
}
