/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Satisfied.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.modifier.adj.mood

import com.zpy.yearn.dict.basic.desire.Desire
import com.zpy.yearn.dict.meta.adv.AdjAdv
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.modifier.Adj
import com.zpy.yearn.dict.meta.thing.{Explainer, Thing}
import com.zpy.yearn.dict.pronoun.sth.Something
import com.zpy.yearn.dict.verb.vt
import com.zpy.yearn.structure.sense.StaticSense

/**
  * Created by zpy on 2019/12/28.
  */
case class Satisfied() extends Adj {
  override def adjMeaning(pred: Pred, centralExplainer: Explainer, advs: Set[AdjAdv]): Either[Option[Thing], Adj] = {
    Left( Some(//todo 声明一种definite: a or s，包括单数和复数
      vt.Satisfy(Something(), Desire().a().of(centralExplainer.fm.asInstanceOf[Ib]) )
    ))
  }
}
object Satisfied extends StaticSense{
  override val words: String = "满意"
}
