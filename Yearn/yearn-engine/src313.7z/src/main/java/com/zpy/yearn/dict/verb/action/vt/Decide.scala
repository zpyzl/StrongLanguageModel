/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Decide.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.vt

import com.zpy.yearn.dict.basic.ib.Thought
import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.{Action, Ib}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVTAction
import com.zpy.yearn.dict.verb.action.vt

/**
  * Created by zpy on 2019/10/11.
  */
case class Decide(override val actor: Ib, override val actionObj: Action ) extends ActionVTAction {

  override def verbMeaning(pred: Pred): Set[Pred] = {
    Set( vt.Create( actor, Thought().whichIs( actionObj.will() )))
  }
}
