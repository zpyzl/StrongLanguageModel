/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Something.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.pronoun.sth

import com.zpy.yearn.dict.meta.thing.Thing

/**
  * Something表示不确定的东西，不应该带seq，所以设为-1，带序号的就是具体的东西了
  * Created by zpy on 2018/12/11.
  */
case class Something( ) extends Thing with TSth {
  override val seq: Int = -1



  //override val chStr: String = "Something"
}
