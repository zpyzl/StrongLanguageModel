/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Agree.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.vt

import com.zpy.yearn.dict.basic.entity.Statements
import com.zpy.yearn.dict.basic.ib.action.Think
import com.zpy.yearn.dict.basic.logic.pred.possibility.Can
import com.zpy.yearn.dict.meta.hasArgs.{Entity, Pred}
import com.zpy.yearn.dict.meta.ib.{Action, Ib}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.verb.action.way

/**
  * Created by zpy on 2019/9/27.
  */
case class Agree(override val actor: Ib, override val obj: Thing ) extends ActionVT {

  override def verbMeaning(pred: Pred): Set[Pred] = {
    obj match {
      case ib: Ib => Set(Agree(actor, Statements().of(ib)))
      case entity: Entity[_] => Set( way.Use(obj = entity).which(Can()))
      case action: Action => Set(
        action.should()
      )
      case pred: Pred => Set( Think( actor, pred ))
      case _ => throw new RuntimeException("agree's obj is wrong!")
    }
  }

  //override val chStr: String = "同意"
}
