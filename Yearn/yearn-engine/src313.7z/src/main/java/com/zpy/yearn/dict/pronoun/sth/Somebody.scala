/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Somebody.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.pronoun.sth

import com.zpy.yearn.dict.meta.ib.Ib

/**
  *
  * Created by zpy on 2019/1/17.
  */
case class Somebody(  ) extends Ib with TSth {
  override def toString: String = "sb"+seq

  //override val chStr: String = "某人"
}
