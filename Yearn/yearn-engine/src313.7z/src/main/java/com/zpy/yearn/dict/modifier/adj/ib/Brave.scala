/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Brave.scala
 * Date:2020/3/8 下午6:06
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.modifier.adj.ib

import com.zpy.yearn.dict.basic.cause.Result
import com.zpy.yearn.dict.basic.ib.action
import com.zpy.yearn.dict.basic.ib.action.Do
import com.zpy.yearn.dict.meta.adv.AdjAdv
import com.zpy.yearn.dict.meta.hasArgs.{Cause, Pred}
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.modifier.Adj
import com.zpy.yearn.dict.meta.modifier.attrClause.Central
import com.zpy.yearn.dict.meta.thing.{Explainer, Thing}
import com.zpy.yearn.dict.pronoun.sth.SomeAction
import com.zpy.yearn.dict.verb.auxVerb
import com.zpy.yearn.dict.verb.auxVerb.Want
import com.zpy.yearn.structure.sense.StaticSense

/**
  * Created by zpy on 2020/3/8.
  */
case class Brave() extends Adj{
  override def adjMeaning(pred: Pred, centralExplainer: Explainer, advs: Set[AdjAdv]): Either[Option[Thing], Adj] = {
    val ib = centralExplainer.fm.asInstanceOf[Ib]
    Left(Some(
      SomeAction(ib).which(
        Want(ib, Result().of(Central()) ).not()
        )
    )
    )
  }
}
object Brave extends StaticSense{
  override val words: String = "勇敢"
}