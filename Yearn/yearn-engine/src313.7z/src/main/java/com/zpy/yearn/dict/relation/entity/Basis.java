/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Basis.java
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.relation.entity;

/**
 * 基础，基本的、主要的原因，A是B的基础，A和B是同一类食物，B从A发展而来
 * Created by zpy on 2018/10/11.
 */
public class Basis{}/* extends Cause {
    @Override
    public String getWordsStr() {
        return "基础";
    }
}
*/