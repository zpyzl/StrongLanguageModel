/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:People.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.noun.ib

import com.zpy.yearn.dict.meta.ib.Ib

/**
  * Created by zpy on 2019/6/5.
  */
case class People(  ) extends Ib {
  //override val chStr: String = "人们"
}
