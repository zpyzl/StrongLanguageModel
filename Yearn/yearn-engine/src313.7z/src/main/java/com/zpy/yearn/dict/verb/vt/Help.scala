/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Help.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.vt

import com.zpy.yearn.dict.meta.hasArgs.{Cause, Pred}
import com.zpy.yearn.dict.meta.predicate.continuous.{VC, VNoneCont}
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.VT
import com.zpy.yearn.dict.meta.thing.Thing
import com.zpy.yearn.dict.modifier.adj.thing.Easy

/**
  * 例子：
  * 这本书帮助我考上了大学
  *
  *
  * Created by zpy on 2019/10/28.
  */
case class Help(override val sbj: Thing, override val obj: Thing ) extends VT{
  override def verbMeaning(pred: Pred): Set[Pred] = {
    Set(
      obj match{
        case vc : VC =>
          new Cause( sbj, vc.copyAddMods(Set( Easy())) )
        case noneCont: VNoneCont =>
          new Cause( sbj, noneCont) //导致结果

      }

    )
  }
}
