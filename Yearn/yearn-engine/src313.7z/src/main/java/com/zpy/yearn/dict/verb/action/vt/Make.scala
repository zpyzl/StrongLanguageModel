/*
 * Copyright(c)2018-2020, 赵鹏阳
 * 项目名称:Yearn 文件名称:Make.scala
 * Date:2020/1/1 下午9:21
 * Author: 赵鹏阳
 */

package com.zpy.yearn.dict.verb.action.vt

import com.zpy.yearn.dict.meta.hasArgs.Pred
import com.zpy.yearn.dict.meta.ib.Ib
import com.zpy.yearn.dict.meta.predicate.hasObjectOrNot.twoArgs.ActionVT
import com.zpy.yearn.dict.meta.thing.Thing

/**
  * 制造
  * Created by zpy on 2019/10/6.
  */
case class Make(override val actor: Ib, override val obj: Thing ) extends ActionVT {
  override def verbMeaning(pred: Pred): Set[Pred] =
    Set( Create(actor, obj))
}
